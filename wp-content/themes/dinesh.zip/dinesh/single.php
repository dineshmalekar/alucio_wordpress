SINGEL.

<?php

get_header();

get_template_part('loop');

get_sidebar();

get_footer('home');

echo theme_url('about-us');

echo site_url();
?>


