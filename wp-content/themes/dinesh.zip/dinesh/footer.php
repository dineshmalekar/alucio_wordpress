footer

<?php
wp_footer();
?>